# My Messenger
## My first project

1. Download;
2. install requirements.txt;
3. if .venv not install →→→ 
py -m venv .venv

or

python -m venv .venv

4. start server: py -m app.main

or

python -m app.main
